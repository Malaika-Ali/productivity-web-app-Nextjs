import { Geist, Geist_Mono } from "next/font/google";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["200", "300", "400", "500", "600", "700", "800"],
});

export const metadata = {
title: {
  template: "%s | Habitrea AI",
  default: "Habitrea AI"
}
};

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
      className={plusJakartaSans.className}
    >
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
